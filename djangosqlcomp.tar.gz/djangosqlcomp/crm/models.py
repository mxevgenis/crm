from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Clients(models.Model):
      name_sur = models.CharField(max_length=40)
      street = models.CharField(max_length=100)
      phone = models.CharField(max_length=10)
      amount = models.IntegerField()
      radevou = models.DateTimeField('date of meeting')
      history = models.CharField(max_length=600)


